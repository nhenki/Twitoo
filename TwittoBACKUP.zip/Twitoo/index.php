<?php
include('classes/database.php');
include('classes/classlogin.php');
include('classes/classpost.php');
include('classes/classcomment.php');

$showTimeline = False;

if(Login::LoggedIn())
{
	$userid = Login::LoggedIn();
	$showTimeline = True;
}
else {
	header('Location: notloggedin.php');
}

if(isset($_GET['postid']))
{
	Post::likePost($_GET['postid'], $userid);
}

if(isset($_POST['comment']))
{
	Comment::createComment($_POST['commentbody'], $_GET['postid2'], $userid);
}

?>

<form action="index.php" method="post">
	<input type="text" name="searchbox" value="">
	<input type="submit" name="search" value="Search User">
</form>

<?php

if(isset($_POST['searchbox']))
{
	//utiliser pour chercher les utilisateurs
	$users = DB::query('SELECT username FROM `utilisateur` WHERE username LIKE :username', array(':username'=>'%'.$_POST['searchbox'].'%'));
	foreach($users as $link)
	{
		echo "Search Result : ";
		echo "<a href='profile.php?username=".htmlspecialchars($link['username'])."'>".htmlspecialchars($link['username'])."</a><br />";
		echo"<hr /></br />";
	}
}
	$prof = DB::query('SELECT utilisateur.username user FROM toklog, utilisateur WHERE userid=:userid AND utilisateur.id=:u_id', array(':userid'=>$userid, ':u_id'=>$userid));
	foreach($prof as $kink)
	{
		echo "<a href='profile.php?username=".htmlspecialchars($kink['user'])."'>Profile Page</a><br />";
		echo "<a href=logout.php>Logout</a>";
		echo"<hr /></br />";
		break;
	}
	

$followingposts = DB::query('SELECT posts.id, posts.body, posts.likes, posts.postat, utilisateur.`username` FROM utilisateur, posts, followers
WHERE posts.user_id = followers.user_id
AND utilisateur.id = posts.user_id
AND folowid = :userid
ORDER BY posts.id DESC;', array(':userid'=>$userid));

foreach($followingposts as $post)
{
	//verifie si le post � �t� liker ou pas
	echo htmlspecialchars($post['body'])." ~ ".htmlspecialchars($post['username'])." ~ ";

	echo "<a href='profile.php?username=".htmlspecialchars($post['username'])."'>Profile</a>";

	echo "<form action='index.php?postid=".htmlspecialchars($post['id'])."' method='post'>";

	if (!DB::query('SELECT post_id FROM post_likes WHERE post_id=:postid AND user_id=:userid', array(':postid'=>$post['id'], ':userid'=>$userid)))
	{
		echo "<input type='submit' name='like' value='Like'>";
	}
	else{
		echo "<input type='submit' name='unlike' value='Unlike'>";
	}
	echo "<span>".htmlspecialchars($post['likes'])." likes</span></form>";
	echo "<span>".htmlspecialchars($post['postat'])."</span></form>";


	echo"<form action='index.php?postid2=".htmlspecialchars($post['id'])."' method='post'>
	<textarea name='commentbody' rows='3' cols='50'></textarea>
    <input type='submit' name='comment' value='Comment'>
	</form>";

	Comment::displayComment($post['id']);

	echo"<hr /></br />";
}
?>