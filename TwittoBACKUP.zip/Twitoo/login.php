<?php
include('classes/database.php');

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>ReseauxSocial</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div class="login-dark" style="height: 1080px;">
        <form action="login.php" method="post">
            <h2 class="sr-only">Login Form</h2>
            <div class="illustration"><i class="icon ion-chatbubbles"></i></div>
            <?php 
                if(isset($_POST['login'])){
	            $username = $_POST['username'];
                $passwd = $_POST['password'];

	            if (DB::query('SELECT username FROM utilisateur WHERE username=:username', array(':username'=>$username)))
	            {
		            //la fonction password_verify fait le dehashing du mot de passe donc tout mot de passe cr�er avant le hashing ne fonctionne plus
		            if (password_verify($passwd, DB::query('SELECT passwd FROM utilisateur WHERE username=:username', array(':username'=>$username))[0]['passwd']))
		            {
			        echo "You've just entered the website";

			        $cstrong = True;
                    $token = bin2hex(openssl_random_pseudo_bytes(64, $cstrong));
                    $userid = DB::query('SELECT id FROM utilisateur WHERE username=:username', array(':username'=>$username))[0]['id'];
                    DB::query('INSERT INTO toklog VALUES (\'\', :token, :userid)', array(':token'=>sha1($token), ':userid'=>$userid));

			        //permet de rester sur le site pendant 60 seconde gr�ce au cookies
			        setcookie("SNICK", $token, time() + 360, '/', NULL, NULL, TRUE);
			        setcookie("SNIP", '1', time() + 330, '/', NULL, NULL, TRUE);

                    //Si le mot de passe est correct ca renvoie l'utilisateur sur l'autre page
                    header('Location: index.php');
		            }
		            else{
			            echo "<center><p>This password is wrong</p></center>";
		            }
	            }
	            else{
		            echo "<center><p>You don't have an account here...</p></center>";
	            }
}           ?>
            <div class="form-group"><input class="form-control" type="text" name="username" placeholder="Username"></div>
            <div class="form-group"><input class="form-control" type="password" id="password" name="password" placeholder="Password"></div>
            <div class="form-group"><input class="btn btn-primary btn-block" type="submit" name="login" value="Login"></button></div><a class="forgot" href="crecompte.php">Don't have an account?</a>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
</body>

</html>