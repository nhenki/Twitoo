
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Reseauxsocial</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div class="login-dark">
        <form method="post">
            <h2 class="sr-only">Login Form</h2>
            <div class="illustration"><i class="icon ion-chatbubbles"></i></div>
            <?php
                include('classes/database.php');

                if (isset($_POST['createaccount'])) {

                $username = $_POST['username'];
                $passwd = $_POST['password'];
                $email = $_POST['email'];

                //v�rifie si l'utilisateur essaye de cr�er un compte avec le m�me username
                if (!DB::query('SELECT username FROM utilisateur WHERE username=:username', array(':username'=>$username)))
                {
                    ////v�rifie si l'utilisateur essaye de cr�er un compte avec plus de 32 caract�res ou moins de 3 caract�res
                    if(strlen($username) >= 3 && strlen($username) <= 32)
                    {
                        //v�rifie si l'utilisateur essaye de cr�er un compte avec un username avec des caract�re invalide
                        if (preg_match('/^[a-zA-Z0-9]*_?[a-zA-Z0-9]*$/', $username))
                        {
                            //v�rifie si le mot de passe entrer a plus de 6 caract�re et moins de 60 caract�res
                            if(strlen($passwd) >= 6 && strlen($passwd) <= 60)
                            {
                                //v�rifie si l'adresse mail entrer est valide
                                if(filter_var($email, FILTER_VALIDATE_EMAIL))
                                {
                                    if((!DB::query('SELECT email FROM utilisateur WHERE email=:email', array(':email'=>$email))))
                                    {
                                        DB::query('INSERT INTO utilisateur VALUES (\'\', :username, :passwd, :email)', array(':username'=>$username, ':passwd'=>password_hash($passwd, PASSWORD_BCRYPT), ':email'=>$email));
                                        header('Location: login.php');
                                        echo "Success!";
								    }
                                    else{
                                        echo "<center><p>You can't use an Email that's already being used</p></center>";
								    }
						        }
                                else{
                                    echo "<center><p>This email is invalid</p></center>";
						        }
						    }
                            else{
                                echo "<center><p>This password is invalid</p></center>";
						    }
                        }
                        else{
                            echo "<center><p>This username is invalid</p></center>";                        
					    }
				    }
                    else{
                        echo "<center><p>This username is invalid</p></center>";        
				    }
		        }
                else {
                    echo "<center><p>You can't just steal someones username !</p></center>";  
	            }
            }

            ?>
            <div class="form-group"><input class="form-control" type="text" name="username" value="" placeholder="Username"></div>
            <div class="form-group"><input class="form-control" type="password" name="password" value="" placeholder="Password"></div>
            <div class="form-group"><input class="form-control" type="email" name="email" placeholder="Email"></div>
            <div class="form-group"><input class="btn btn-primary btn-block" type="submit"  name="createaccount" value="Create Account"></button></div><a class="forgot" href="login.php">Already got an Account ?</a></form>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>