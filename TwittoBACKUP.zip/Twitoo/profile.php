<?php
include('classes/database.php');
include('classes/classlogin.php');
include('classes/classpost.php');

if(!Login::LoggedIn())
{
	header('Location: notloggedin.php');
}

$username = "";
$isFollowing = False;
if(isset($_GET['username']))
{
	if (DB::query('SELECT username FROM utilisateur WHERE username=:username', array(':username'=>$_GET['username'])))
	{
		$username = DB::query('SELECT username FROM utilisateur WHERE username=:username', array(':username'=>$_GET['username']))[0]['username'];
		$userid = DB::query('SELECT id FROM utilisateur WHERE username=:username', array(':username'=>$_GET['username']))[0]['id'];
        $followerid = Login::LoggedIn();

		//Permet de suivre une personne
		if(isset($_POST['follow'])) 
		{
			//Empeche l'utilisateur de suivre son propre compte
			if ($userid != $followerid) 
			{
				if (!DB::query('SELECT folowid FROM followers WHERE user_id=:userid AND folowid=:followerid', array(':userid'=>$userid, ':followerid'=>$followerid)))
				{
					//ajoute le fait que tu suit quelqu'un � la base de donn�e
					DB::query('INSERT INTO followers VALUES (\'\', :userid, :followerid)', array(':userid'=>$userid, ':followerid'=>$followerid));
				} else {
					echo 'Already following!';
				}
				$isFollowing = True;
			}
		}
		//Permet de ne plus suivre une personne
		if (isset($_POST['unfollow'])) 
		{
			//Empeche l'utilisateur d'arr�ter de suivre son propre compte
			if ($userid != $followerid)
			{
				if (DB::query('SELECT folowid FROM followers WHERE user_id=:userid AND folowid=:followerid', array(':userid'=>$userid, ':followerid'=>$followerid)))
				{
					//supprime le fait que tu suit quelqu'un de la base de donn�e
					DB::query('DELETE FROM followers WHERE user_id=:userid AND folowid=:followerid', array(':userid'=>$userid, ':followerid'=>$followerid));
                }
				$isFollowing = False;
			}
		}
        if (DB::query('SELECT folowid FROM followers WHERE user_id=:userid AND folowid=:followerid', array(':userid'=>$userid, ':followerid'=>$followerid))) {
			$isFollowing = True;
        }

		if (isset($_POST['deletepost']))
		{
			if (DB::query('SELECT id FROM posts WHERE id=:postid AND user_id=:userid', array(':postid'=>$_GET['postid'], ':userid'=>$followerid)))
			{
				DB::query('DELETE FROM posts WHERE id=:postid and user_id=:userid', array(':postid'=>$_GET['postid'], ':userid'=>$followerid));
                DB::query('DELETE FROM post_likes WHERE post_id=:postid', array(':postid'=>$_GET['postid']));
                echo 'Post deleted!';
			}
		}
		
		if(isset($_POST['post']))
		{
			Post::createPost($_POST['postbody'], Login::LoggedIn(), $userid);
		}

		if(isset($_GET['postid']) && !isset($_POST['deletepost']))
		{
			Post::likePost($_GET['postid'], $followerid);
		}

		$posts = Post::displaypost($userid, $username, $followerid);

	}
	else{
		die('User not found');
	}
}

?>

<h1><?php echo htmlspecialchars($username); ?>'s Profile</h1>
<a href=index.php>Timeline</a>  ~ 
<a href=changepass.php>Change Password</a> ~ 
<a href=changename.php>Change Username</a> ~ 
<a href=logout.php>Logout</a>
<form action="profile.php?username=<?php echo htmlspecialchars($username) ?>" method="post">
		<?php
		//Empeche l'utilisateur de suivre son propre compte
		if ($userid != $followerid) {
                if ($isFollowing) {
                        echo '<input type="submit" name="unfollow" value="Unfollow">';
                } else {
                        echo '<input type="submit" name="follow" value="Follow">';
                }
        }
		?>

</form>
<form action="profile.php?username=<?php echo htmlspecialchars($username) ?>" method="post">
	<textarea name="postbody" rows="8" cols="80"></textarea>
	<input type="submit" name="post" value="Post">
</form>

<div class="posts">
	<?php echo $posts; ?>
</div>