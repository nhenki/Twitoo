<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Reseauxsocial</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div class="login-dark">
        <form method="post">
            <h2 class="sr-only">Login Form</h2>
            <div class="illustration"><i class="icon ion-chatbubbles"></i></div>

<?php
include('classes/database.php');
include('classes/classlogin.php');

if(!Login::LoggedIn())
{
	header('Location: notloggedin.php');
}

if(isset($_POST['logout']))
{
	if(isset($_POST['alldevices']))
	{
		DB::query('DELETE FROM toklog WHERE userid=:user_id', array(':user_id'=>Login::LoggedIn()));
	}
	else{
		if(isset($_COOKIE['SNICK']))
		{
			DB::query('DELETE FROM toklog WHERE token=:token', array(':token'=>sha1($_COOKIE['SNICK'])));
		}
		setcookie('SNICK', '1', time()-3600);
		setcookie('SNIP', '1', time()-3600);
	}
}

?>

<div class="form-group">
            <div class="form-group"><center><input type="checkbox" name="alldevices" value="alldevices"> Logout of all devices ? </center><br /></div>
            <div class="form-group"><input class="btn btn-primary btn-block" type="submit"  name="logout" value="Logout"></button></div><a class="forgot" href="index.php">Don't want to log out ?</a></form>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>