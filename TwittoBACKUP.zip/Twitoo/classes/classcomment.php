<?php

class Comment{

	public static function createComment($commentbody, $postId, $userId)
	{
		//Empeche de cr�er un post trop long
		if(strlen($commentbody)>140 || strlen($commentbody)<1)
		{
			die('Invalid Post');
		}

		if(!DB::query('SELECT id FROM posts WHERE id=:postid', array(':postid'=>$postId)))
		{
			echo "Invalid Post ID";
		}
		else{
			DB::query('INSERT INTO comments VALUES (\'\', :comment, :userid, NOW(), :postid)', array(':comment'=>$commentbody, ':userid'=>$userId, ':postid'=>$postId));
		}
	}

	public static function displayComment($postId)
	{
		$comments = DB::query('SELECT comments.comment, comments.posted_at, utilisateur.username FROM comments, utilisateur WHERE post_id = :postid AND comments.user_id = utilisateur.id ORDER BY comments.id DESC', array(':postid'=>$postId));
		foreach($comments as $comment)
		{
			echo $comment['comment']." ~ ".$comment['username']."<br /><br />";
			echo $comment['posted_at']."<hr />";
		}
	}
}


?>