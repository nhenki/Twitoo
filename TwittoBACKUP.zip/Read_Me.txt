Participants :

Léo Bourlier et Arthur Cottreau


Problème majeur rencontré:

-Nous n'avons pas pu creer un bootstrap, malgré tout notre  site est fonctionnel
mais cela ne nous a pas permis de pouvoir le mettre en ligne.

-Système de retweet(non réalisé) due à la structure de post ou de commentaire

-CSS non réalisé sur les pages profil et index due a la structure


Les fonctionalitées réalisées:

-réalisation de comtpe 
-connexion à un compte existant
-système de timeline ( en cas de follow )
-possibilité de follow d'autres comptes
-création de posts
-visualisation et personalisation de son propre profil
-visualisation des autres profils et de leur posts
-changement d'informations personnelles dans le profil de l'utilisateur
-systeme de like
-visualisation des posts des utilisateurs suivis
-barre de recherche d'autres utilisateurs
-possibilitée de se déconnecter de notre compte
-ajouter un commentaire au posts des autres utilisateurs


Bonus tentés :

-Mise en page css pour la plupart des pages du site


Archive de notre projet :

Tous les fichiers de notre site sont disponible dans le dossier Twitoo

