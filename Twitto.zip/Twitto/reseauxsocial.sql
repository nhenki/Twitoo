-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 16 juin 2020 à 03:47
-- Version du serveur :  10.4.11-MariaDB
-- Version de PHP : 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `reseauxsocial`
--

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) UNSIGNED NOT NULL,
  `comment` text NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `posted_at` datetime NOT NULL,
  `post_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `comments`
--

INSERT INTO `comments` (`id`, `comment`, `user_id`, `posted_at`, `post_id`) VALUES
(1, 'its me', 8, '2020-06-15 02:28:07', 6),
(2, 'hey guys pyro here', 6, '2020-06-15 02:30:05', 6),
(5, 'hell', 6, '2020-06-15 02:31:19', 6),
(6, 'hell', 8, '2020-06-15 02:31:38', 6),
(7, 'sukc my pokemno', 8, '2020-06-15 02:31:47', 6),
(8, 'ahaha', 8, '2020-06-15 02:31:56', 6),
(9, 'ahaha', 6, '2020-06-15 02:37:10', 6),
(10, 'ahaha', 6, '2020-06-15 02:37:34', 6),
(13, 'this is shit', 6, '2020-06-15 02:38:33', 6),
(14, 'ha', 6, '2020-06-15 02:38:38', 6),
(15, 'stop', 6, '2020-06-15 02:38:41', 6),
(16, 'stop', 6, '2020-06-15 02:38:47', 6),
(17, 'quitit', 6, '2020-06-15 02:38:54', 6),
(18, 'quitit', 6, '2020-06-15 02:40:28', 6),
(19, 'This is dumb', 6, '2020-06-15 02:40:38', 6),
(20, 'This is dumb', 6, '2020-06-15 02:49:13', 6),
(21, 'This is dumb', 6, '2020-06-15 02:50:30', 6),
(22, 'yeah', 6, '2020-06-15 02:50:41', 6),
(23, 'yeah', 6, '2020-06-15 02:53:01', 6),
(24, 'c\'est le plus recent', 6, '2020-06-15 02:53:09', 6),
(25, 'yes j\'ai reussi', 6, '2020-06-15 02:53:18', 6),
(26, 'yes j\'ai reussi', 6, '2020-06-15 02:55:41', 6),
(27, 'yes j\'ai reussi', 6, '2020-06-15 02:55:43', 6),
(29, 'Hey', 8, '2020-06-15 20:08:51', 11),
(30, 'That\'s pretty Cool', 8, '2020-06-15 20:09:04', 11),
(31, 'mmh I don\'t like this', 8, '2020-06-16 03:39:32', 11);

-- --------------------------------------------------------

--
-- Structure de la table `followers`
--

CREATE TABLE `followers` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `folowid` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `followers`
--

INSERT INTO `followers` (`id`, `user_id`, `folowid`) VALUES
(23, 7, 6),
(24, 8, 6),
(25, 6, 8),
(26, 7, 8),
(27, 6, 9);

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) UNSIGNED NOT NULL,
  `body` varchar(160) NOT NULL,
  `postat` datetime NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `likes` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `posts`
--

INSERT INTO `posts` (`id`, `body`, `postat`, `user_id`, `likes`) VALUES
(6, 'Hello again', '2020-06-14 17:33:07', 6, 1),
(11, 'Leo', '2020-06-15 17:14:05', 6, 1),
(12, 'wowie', '2020-06-16 03:39:45', 8, 0),
(13, 'He pissed all over my wife, and then said it was \'this big\', so know i\'ll blow up the moon.', '2020-06-16 03:45:35', 6, 0);

-- --------------------------------------------------------

--
-- Structure de la table `post_likes`
--

CREATE TABLE `post_likes` (
  `id` int(11) UNSIGNED NOT NULL,
  `post_id` int(11) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `post_likes`
--

INSERT INTO `post_likes` (`id`, `post_id`, `user_id`) VALUES
(47, 10, 6),
(51, 1, 6),
(52, 2, 6),
(54, 6, 0),
(55, 6, 6),
(59, 11, 0),
(61, 6, 8);

-- --------------------------------------------------------

--
-- Structure de la table `toklog`
--

CREATE TABLE `toklog` (
  `id` int(11) UNSIGNED NOT NULL,
  `token` char(64) NOT NULL,
  `userid` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `toklog`
--

INSERT INTO `toklog` (`id`, `token`, `userid`) VALUES
(268, 'b171d6cbc721dfa64555330478709419a3b208f5', 8);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(32) DEFAULT NULL,
  `passwd` varchar(60) DEFAULT NULL,
  `email` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `username`, `passwd`, `email`) VALUES
(6, 'jimthedoor', '$2y$10$V/5FQWkXI3YfQ3NBshWTp.dclx1jioXatrKmhnZHkzoRupQvKTuRK', 'no@dick.fr'),
(7, 'try', '$2y$10$rU.LLLLelNFazTL3y.4b3evwUmMplLR63Hz6QBmBAK11IK0821S5O', 'bob@dmail.fr'),
(8, 'arcottreau', '$2y$10$KNGlR5hGkKgAEI/91fvVTuIaVxLNiEIORppICKSdA9JheLk6QIf1G', 'homelessmangamin@help.g'),
(9, 'sam', '$2y$10$VW8oB7AnJRle71VyIpsLw.F1RfLoKWhUHjdelYWKjD85e20FpOODe', 'bob@reail.fr'),
(10, 'timpool', '$2y$10$xCMNTT0y7xE49Z29VvDTD.FZ4Ya5bz7CgyZQOsjWzUB3E0d4VqVLC', 'boby@dmail.fr');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `post_id` (`post_id`);

--
-- Index pour la table `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `toklog`
--
ALTER TABLE `toklog`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQUE` (`token`),
  ADD KEY `userid` (`userid`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT pour la table `followers`
--
ALTER TABLE `followers`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT pour la table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `post_likes`
--
ALTER TABLE `post_likes`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT pour la table `toklog`
--
ALTER TABLE `toklog`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=269;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`);

--
-- Contraintes pour la table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `utilisateur` (`id`);

--
-- Contraintes pour la table `toklog`
--
ALTER TABLE `toklog`
  ADD CONSTRAINT `toklog_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `utilisateur` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
