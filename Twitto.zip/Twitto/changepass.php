<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Reseauxsocial</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div class="login-dark">
        <form method="post">
            <h2 class="sr-only">Login Form</h2>
            <div class="illustration"><i class="icon ion-chatbubbles"></i></div>

            <?php
				include('classes/database.php');
				include('classes/classlogin.php');


				if(Login::LoggedIn())
				{
					if(isset($_POST['changepassword']))
					{
						$oldpasswd = $_POST['oldpassword'];
						$newpasswd = $_POST['newpassword'];
						$newpasswdrpt = $_POST['newpasswordrepeat'];
						$user_id = Login::LoggedIn();

						//verifie si le vieu mot de passe est correct
						if(password_verify($oldpasswd, DB::query('SELECT passwd FROM utilisateur WHERE id=:user_id', array(':user_id'=>$user_id))[0]['passwd']))
						{
							//Si le nouveau mot de passe et le nouveau mot de passe re-entrer son identique faut changer le mot de passe
							if($newpasswd == $newpasswdrpt)
							{
								//Empecher que le mot de passe soit moins de 6 caract�re ou plus de 60 caract�re
								if(strlen($newpasswd) >= 6 && strlen($newpasswd) <= 60)
								{
									DB::query('UPDATE utilisateur SET passwd=:newpassword WHERE id=:user_id', array(':newpassword'=>password_hash($newpasswd, PASSWORD_BCRYPT), ':user_id'=>$user_id));
									echo "<p><center>Password changed</p></center>";
								}
								else{
									echo "<p><center>Invalid New Password</p></center>";;
								}
							}
							else{
								echo "<p><center>Passwords don't match</p></center>";
							}
						}
						else{
							echo "<p><center>Incorrect old password</p></center>";
						}
					}
				}
				else {
					header('Location: notloggedin.php');
				}
			?>
            <div class="form-group"><input class="form-control" type="password" name="oldpassword" value="" placeholder="Current Password"></div>
            <div class="form-group"><input class="form-control" type="password" name="newpassword" value="" placeholder="New Password"></div>
            <div class="form-group"><input class="form-control" type="password" name="newpasswordrepeat" value="" placeholder="Repeat Password"></div>
            <div class="form-group"><input class="btn btn-primary btn-block" type="submit" name="changepassword" value="Change Password"></button></div>
        </form>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>