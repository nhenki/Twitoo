<?php

class Post {

	public static function createPost($postbody, $loggedinuserid, $profileid)
	{
		//Empeche de cr�er un post trop long
		if(strlen($postbody)>140 || strlen($postbody)<1)
		{
			die('Invalid Post');
		}

		//Empeche de cr�er un post sur le compte de quelqu'un d'autre
		if ($loggedinuserid == $profileid)
		{
			DB::query('INSERT INTO posts VALUES (\'\', :postbody, NOW(), :userid, 0)', array(':postbody'=>$postbody, ':userid'=>$profileid));
		}
		else{
			die('You are trying to post on someone elses profile !!!');
		}
	}

	public static function likePost($postid, $likeid)
	{
		//v�rifie si le post a �t� d�j� liker
		if(!DB::query('SELECT user_id FROM post_likes WHERE post_id=:postid AND user_id=:userid', array(':postid'=>$postid, ':userid'=>$likeid)))
		{
			DB::query('UPDATE posts SET likes=likes+1 WHERE id=:postid', array(':postid'=>$postid));
			DB::query('INSERT INTO post_likes VALUES (\'\', :postid, :userid)', array(':postid'=>$postid, ':userid'=>$likeid));
		}
		else{
			DB::query('UPDATE posts SET likes=likes-1 WHERE id=:postid', array(':postid'=>$postid));
			DB::query('DELETE FROM post_likes WHERE post_id=:postid AND user_id=:userid', array(':postid'=>$postid, ':userid'=>$likeid));
		}

	}

	public static function displaypost ($userid, $username, $loggedinuserid)
	{
		//r�cup�re les post de la base de donn�, et odre par leur id
		$dbposts = DB::query('SELECT * FROM posts WHERE user_id=:userid ORDER BY id DESC', array(':userid'=>$userid));
		$posts = "";
		//affiche tout les posts un par un
		foreach($dbposts as $p)
		{
			//verifie si le post � �t� liker ou pas
			if (!DB::query('SELECT post_id FROM post_likes WHERE post_id=:postid AND user_id=:userid', array(':postid'=>$p['id'], ':userid'=>$loggedinuserid)))
			{
				//htmlspecialchars em�che l'utilisateur d'utiliser du code html dans un post
				//affiche les posts et les boutons like
				$posts .= htmlspecialchars($p['body'])."
				<form action='profile.php?username=$username&postid=".$p['id']."' method='post'>
					<input type='submit' name='like' value='Like'>
					~ <span>".$p['likes']." likes</span>
				";
				
				if($userid == $loggedinuserid)
				{
					$posts .= "<input type='submit' name='deletepost' value='x' />";
				}
				$posts .= "
				<p>".$p['postat']." </p>
				</form><hr /></br />
				";
			}
			else{
				//htmlspecialchars em�che l'utilisateur d'utiliser du code html dans un post
				//affiche les posts et les boutons dislike
				$posts .= htmlspecialchars($p['body'])."
				<form action='profile.php?username=$username&postid=".$p['id']."' method='post'>
					<input type='submit' name='unlike' value='Unlike'>
					<span>".$p['likes']." likes</span>
				";
				if($userid == $loggedinuserid)
				{
					$posts .= "<input type='submit' name='deletepost' value='x' />";
				}
				$posts .= "
				</form><hr /></br />
				";
			}
		}
		return $posts;
	}
}

?>