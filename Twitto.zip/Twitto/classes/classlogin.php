<?php

class Login 
{
	public static function LoggedIn()
	{
		if (isset($_COOKIE['SNICK']))
		{
			//v�rifie si l'utilisateur devrait tjrs �tre connecter
			if(DB::query('SELECT userid FROM toklog WHERE token=:token', array(':token'=>sha1($_COOKIE['SNICK']))))
			{
				$user_id = DB::query('SELECT userid FROM toklog WHERE token=:token', array(':token'=>sha1($_COOKIE['SNICK'])))[0]['userid'];
			
				if (isset($_COOKIE['SNIP']))
				{
					return $user_id;
				}
				else{
					$cstrong = True;
					$token = bin2hex(openssl_random_pseudo_bytes(64, $cstrong));
					DB::query('INSERT INTO toklog VALUES (\'\', :token, :userid)', array(':token'=>sha1($token), ':userid'=>$user_id));
					DB::query('DELETE FROM toklog WHERE token=:token', array(':token'=>sha1($_COOKIE['SNICK'])));

					//Juge la dur�e de connection gr�ce � des cookies
					setcookie("SNICK", $token, time() + 360, '/', NULL, NULL, TRUE);
					setcookie("SNIP", '1', time() + 330, '/', NULL, NULL, TRUE);

					return $user_id;
				}
			}
		}
		return false;
	}
}
?>