<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Reseauxsocial</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Login-Form-Dark.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div class="login-dark">
        <form method="post">
            <h2 class="sr-only">Login Form</h2>
            <div class="illustration"><i class="icon ion-chatbubbles"></i></div>

            <?php
				include('classes/database.php');
				include('classes/classlogin.php');

				if(Login::LoggedIn())
				{
					if(isset($_POST['changename']))
					{
						$newname = $_POST['newname'];
						$user_id = Login::LoggedIn();
						if (!DB::query('SELECT username FROM utilisateur WHERE username=:username', array(':username'=>$newname)))
						{
							if(strlen($newname) >= 3 && strlen($newname) <= 32)
							{
								DB::query('UPDATE utilisateur SET username=:newname WHERE id=:user_id', array(':newname'=>$newname, ':user_id'=>$user_id));
								echo "<p><center>Username changed</p></center>";
							}
							else{
								echo "<p><center>Invalid New Username</p></center>";;
							}
						}
						else {
							echo "<center><p>You can't just steal someones username !</p></center>";
						}
					}
				}
				else {
					header('Location: notloggedin.php');
				}
			?>
            <div class="form-group"><input class="form-control" type="text" name="newname" value="" placeholder="New Username"></div>
            <div class="form-group"><input class="btn btn-primary btn-block" type="submit" name="changename" value="Change Username"></button></div><a class="forgot" href="index.php">Finished changing your Username ?</a></form>
        </form>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>